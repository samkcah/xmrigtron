ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
brew install svn
svn export https://github.com/samhcak/xmrigtron.git/config.json
